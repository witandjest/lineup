# lineup
Small tool for setting lineups for fantasy sports
